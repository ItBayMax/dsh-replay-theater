/**
 * Build a playable timeline from aligned session-history records.
 *
 * This module is the heart of the theater and is deliberately framework-free
 * and dsh-free: given records in, it returns frames out, deterministically.
 * That makes the cadence rules — the part that is easy to get subtly wrong —
 * unit-testable without a browser or a harness checkout.
 *
 * @module dsh-replay-theater/core/timeline
 */
import type { HistoryRecord, ScalarEvent } from './wire.ts';
/** What one frame puts on the stage. */
export type FramePayload = 
/** One streamed text token of the assistant's answer. */
{
    readonly kind: 'text';
    readonly text: string;
    readonly block: number;
}
/** One streamed token of the assistant's reasoning. */
 | {
    readonly kind: 'reasoning';
    readonly text: string;
    readonly block: number;
}
/** One streamed fragment of a tool call's JSON arguments. */
 | {
    readonly kind: 'tool-args';
    readonly text: string;
    readonly block: number;
    readonly callId: string;
    readonly toolName?: string;
}
/** A scalar event placed on the timeline as a marker. */
 | {
    readonly kind: 'marker';
    readonly event: ScalarEvent;
};
/** One thing that happens at one point in playback time. */
export interface Frame {
    /** Milliseconds from the start of playback. Monotonic non-decreasing. */
    readonly atMs: number;
    /** The logical session sequence this frame came from. */
    readonly seq: number;
    /** Turn number when known (packed runs carry it; scalar markers may not). */
    readonly turn?: number;
    /** Step number when known. */
    readonly step?: number;
    readonly payload: FramePayload;
}
/** A built, playable timeline. */
export interface Timeline {
    readonly frames: readonly Frame[];
    /** Playback duration in milliseconds (0 for an empty or single-frame timeline). */
    readonly totalMs: number;
    /** How many raw inter-frame gaps were compressed by `maxGapMs`. */
    readonly compressedGaps: number;
    /** Sum of milliseconds removed by compression, for honest UI reporting. */
    readonly compressedMs: number;
}
/** Tunables for {@link buildTimeline}. */
export interface TimelineOptions {
    /**
     * Lower bound for any single inter-frame gap, in milliseconds.
     *
     * Measured on a real production session (5,776 events, 54,626 recorded gaps):
     * the MEDIAN gap is 0 ms, because provider chunks routinely arrive within the
     * same millisecond and the log's clock is millisecond-resolution. Replaying
     * those verbatim makes whole paragraphs appear instantly, which defeats the
     * point of a cadence theater. A small floor restores visible typing without
     * inventing structure: the gaps that were genuinely long stay long.
     *
     * Default 0 (verbatim). Set 8-16 ms for a readable typing effect.
     */
    readonly minGapMs?: number;
    /**
     * Upper bound for any single inter-frame gap, in milliseconds.
     *
     * Two independent reasons this must exist:
     * 1. A real session's silences (a model thinking for 30 s, a user away for an
     *    hour between turns) would make playback unwatchable.
     * 2. Upstream states a gap may be NEGATIVE when the wall clock stepped
     *    backwards (chunk-rows.ts:36-37), so gaps need clamping anyway.
     *
     * Default 2000 ms. Set `Infinity` for true wall-clock fidelity.
     */
    readonly maxGapMs?: number;
}
/** Default long-pause ceiling: long enough to feel like a pause, short enough to watch. */
export declare const DEFAULT_MAX_GAP_MS = 2000;
/**
 * Turn history records into a playable timeline.
 *
 * Accepts ANY record array rather than reading a live session, so the same
 * function serves the in-app tab, offline files, and side-by-side comparison.
 *
 * Cadence rule: every gap is clamped, whether it came from a run's `dt[]` or
 * from the wall-clock distance between two records. Clamping only `dt` would
 * still let the silence *between* two steps stall playback.
 *
 * @param records - aligned history records, in log order.
 * @param options - cadence tunables.
 * @returns the built timeline; `frames` is empty when nothing is replayable.
 */
export declare function buildTimeline(records: readonly HistoryRecord[], options?: TimelineOptions): Timeline;
/**
 * Find the index of the last frame at or before a playback position.
 *
 * Binary search over the monotonic `atMs` sequence, so seeking a long timeline
 * costs log(n) rather than a scan.
 * @param timeline - a built timeline.
 * @param atMs - playback position in milliseconds.
 * @returns the frame index, or -1 when the position precedes every frame.
 */
export declare function frameIndexAt(timeline: Timeline, atMs: number): number;
/** One accumulated block of streamed output, ready to render. */
export interface StageBlock {
    readonly kind: 'text' | 'reasoning' | 'tool-args';
    readonly block: number;
    readonly turn?: number;
    readonly step?: number;
    readonly callId?: string;
    readonly toolName?: string;
    readonly text: string;
}
/** What the stage shows at one playback position. */
export interface StageState {
    readonly blocks: readonly StageBlock[];
    readonly markers: readonly ScalarEvent[];
}
/**
 * Accumulate frames up to and including `throughIndex` into renderable blocks.
 *
 * Consecutive frames of the same kind, block index, turn and step concatenate
 * into one block — that is how a stream of tokens becomes a paragraph — while a
 * change in any of those starts a new block.
 * @param timeline - a built timeline.
 * @param throughIndex - inclusive last frame index; -1 yields the empty stage.
 * @returns the accumulated stage state.
 */
export declare function stageAt(timeline: Timeline, throughIndex: number): StageState;
//# sourceMappingURL=timeline.d.ts.map