/**
 * Playback state machine.
 *
 * React-free and clock-injectable so playback rules are unit-testable without
 * timers or a DOM: the owner advances it with `tick(nowMs)` and the machine
 * decides where the playhead lands. Nothing here schedules work.
 *
 * @module dsh-replay-theater/core/player
 */
import type { Timeline } from './timeline.ts';
/** Playback speeds the UI offers. */
export declare const SPEEDS: readonly [0.5, 1, 2, 4, 8];
/** One offered playback speed. */
export type Speed = typeof SPEEDS[number];
/** Immutable playback state. */
export interface PlayerState {
    /** Playhead position in timeline milliseconds. */
    readonly positionMs: number;
    /** Whether the playhead is advancing. */
    readonly playing: boolean;
    /** Playback rate multiplier. */
    readonly speed: Speed;
    /**
     * Index of the last frame at or before the playhead; -1 before the first.
     * Kept in state (not derived per render) so the stage can memoize on it.
     */
    readonly frameIndex: number;
    /** Wall-clock reading of the last `tick`, or undefined while paused. */
    readonly lastTickMs?: number;
}
/** A player bound to one timeline. */
export interface Player {
    readonly state: PlayerState;
    readonly timeline: Timeline;
}
/**
 * Create a paused player at the start of a timeline.
 * @param timeline - the timeline to play.
 * @returns a player positioned before the first frame.
 */
export declare function createPlayer(timeline: Timeline): Player;
/**
 * Rebind a player to a new timeline, keeping the playhead where it still fits.
 *
 * Playback continues across a window growth (the user paged older history in,
 * or a live turn appended frames) instead of snapping back to the start, which
 * would make "load earlier" unusable while playing.
 * @param player - the current player.
 * @param timeline - the replacement timeline.
 * @returns a player on the new timeline.
 */
export declare function retarget(player: Player, timeline: Timeline): Player;
/**
 * Start playing from the current position.
 *
 * Restarts from zero when the playhead already sits at the end, so the play
 * button never looks dead.
 * @param player - the current player.
 * @param nowMs - wall-clock reading that anchors the first tick.
 * @returns the playing player.
 */
export declare function play(player: Player, nowMs: number): Player;
/**
 * Pause at the current position.
 * @param player - the current player.
 * @returns the paused player.
 */
export declare function pause(player: Player): Player;
/**
 * Advance the playhead to a wall-clock reading.
 *
 * Elapsed wall time is scaled by `speed`; reaching the end stops playback so a
 * finished replay does not keep burning animation frames.
 * @param player - the current player.
 * @param nowMs - current wall-clock reading.
 * @returns the advanced player, or the same object when not playing.
 */
export declare function tick(player: Player, nowMs: number): Player;
/**
 * Move the playhead to an absolute position, clamped to the timeline.
 * @param player - the current player.
 * @param positionMs - requested position in timeline milliseconds.
 * @param nowMs - wall-clock reading, used to re-anchor an active playback.
 * @returns the seeked player.
 */
export declare function seek(player: Player, positionMs: number, nowMs: number): Player;
/**
 * Move the playhead by whole frames.
 *
 * Stepping pauses: single-stepping while playing would fight the tick loop.
 * @param player - the current player.
 * @param delta - frames to move; negative steps backwards.
 * @returns the stepped, paused player.
 */
export declare function step(player: Player, delta: number): Player;
/**
 * Set the playback rate, keeping the playhead and re-anchoring the clock.
 * @param player - the current player.
 * @param speed - the new rate.
 * @param nowMs - wall-clock reading.
 * @returns the player at the new rate.
 */
export declare function setSpeed(player: Player, speed: Speed, nowMs: number): Player;
/**
 * Return to the start, paused.
 * @param player - the current player.
 * @returns the rewound player.
 */
export declare function restart(player: Player): Player;
//# sourceMappingURL=player.d.ts.map