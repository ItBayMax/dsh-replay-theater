/**
 * Compare two timelines: where they agree, where they first diverge.
 *
 * This is the piece that makes the theater useful beyond watching one session:
 * two runs of the same task — different model, different preset, different
 * provider — replay side by side, and the comparison names the exact point
 * where their output stopped matching.
 *
 * It works on built timelines rather than on sessions, so the same function
 * serves live windows, offline files, and any future evaluation report.
 *
 * @module dsh-replay-theater/core/compare
 */
import type { Timeline } from './timeline.ts';
/** How two timelines relate. */
export type Divergence = 
/** The compared prefixes are identical for their whole shared length. */
{
    readonly kind: 'identical';
    /** How many frames were compared. */
    readonly comparedFrames: number;
    /** True when one side simply has more frames after the shared prefix. */
    readonly lengthDiffers: boolean;
}
/** The sides differ, first at this frame index. */
 | {
    readonly kind: 'diverged';
    /** Frame index (same on both sides) where the first difference appears. */
    readonly atFrame: number;
    /** Sequence numbers at that frame, when the frame exists on that side. */
    readonly leftSeq?: number;
    readonly rightSeq?: number;
    /** Playback positions of that frame, for seeking both players there. */
    readonly leftAtMs?: number;
    readonly rightAtMs?: number;
    /** What differed, for a one-line explanation. */
    readonly reason: 'payload-kind' | 'text' | 'marker-type' | 'left-ended' | 'right-ended';
};
/**
 * Find the first frame where two timelines stop matching.
 *
 * @param left - one timeline.
 * @param right - the other timeline.
 * @returns the divergence description.
 */
export declare function findDivergence(left: Timeline, right: Timeline): Divergence;
/** Accumulated text of one side, for a coarse "what did each produce" view. */
export interface SideSummary {
    readonly frames: number;
    readonly totalMs: number;
    /** Concatenated assistant text (excludes reasoning and tool arguments). */
    readonly text: string;
    /** Concatenated reasoning text. */
    readonly reasoning: string;
    /** Distinct tool names seen, in first-seen order. */
    readonly tools: readonly string[];
}
/**
 * Summarize one whole timeline.
 *
 * Useful on its own (a compact "what happened" line) and as the basis of a
 * comparison table when two runs are shown side by side.
 * @param timeline - the timeline to summarize.
 * @returns the summary.
 */
export declare function summarize(timeline: Timeline): SideSummary;
//# sourceMappingURL=compare.d.ts.map