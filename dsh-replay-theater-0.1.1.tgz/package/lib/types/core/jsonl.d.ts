/**
 * Read a recorded `session.jsonl` into history records.
 *
 * This is the offline half of the theater: a file dropped into the browser (or
 * read by a script) becomes the same `HistoryRecord[]` the live window
 * provides, so `buildTimeline` serves both paths unchanged.
 *
 * A JSONL storage line and a client wire record are NOT the same shape, and
 * conflating them is the easiest mistake to make here:
 *
 * | | storage line (this module's input) | client wire record |
 * |---|---|---|
 * | packed | `{ type: 'text-chunks', seq0, time0, data }` | `{ type: 'chunks', event: { type: 'chunkrow/text-chunks', seq, time, data } }` |
 * | scalar | the event itself, with `seq`/`time` | `{ type: 'event', event }` |
 *
 * The `seq0`/`time0` naming of a packed storage row is easy to miss and was
 * verified against a real 5777-line production log: 2455 of its rows are packed
 * and carry `seq0`/`time0`, 1267 are scalar and carry `seq`/`time`, and the
 * first line is a `SessionHeader` (`{type:'session', version, id, createdAt,
 * cwd, …}`) with NEITHER — it is session metadata, not an event, so it must not
 * consume a sequence.
 *
 * Upstream's own decoder for the storage form is `decodeStorageRecord`
 * (packages/core/session/src/chunk-rows.ts:363); this module performs the
 * equivalent recognition and then lifts the result into wire records.
 *
 * @module dsh-replay-theater/core/jsonl
 */
import type { HistoryRecord } from './wire.ts';
/** Outcome of parsing one file. */
export interface ParsedLog {
    readonly records: readonly HistoryRecord[];
    /** Lines that were not usable, with 1-based line numbers, for honest reporting. */
    readonly skipped: readonly {
        readonly line: number;
        readonly reason: string;
    }[];
    /**
     * The log's `SessionHeader` line when present. It is session metadata rather
     * than an event (no `seq`, no `time`), so it stays out of `records`.
     */
    readonly header?: Record<string, unknown>;
}
/**
 * Parse a recorded session log into history records.
 *
 * Normalized snapshot corpora strip `seq` and `time` (snapshots/AGENTS.md), so
 * a line without them gets its line-order sequence and a synthetic clock: the
 * result stays playable, only its cadence becomes uniform. Whether times were
 * synthesized is reported so a UI can say so rather than implying real cadence.
 *
 * @param text - the whole file contents.
 * @param options - synthetic clock settings for logs without timestamps.
 * @returns records plus a list of skipped lines.
 */
export declare function parseSessionLog(text: string, options?: {
    readonly syntheticGapMs?: number;
}): ParsedLog & {
    readonly synthesizedTimes: boolean;
};
//# sourceMappingURL=jsonl.d.ts.map