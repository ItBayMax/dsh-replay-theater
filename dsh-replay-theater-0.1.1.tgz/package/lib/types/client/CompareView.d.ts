/**
 * Side-by-side replay of two timelines, with the first divergence named.
 *
 * This is the piece that turns the theater into an evaluation surface: two runs
 * of the same task replay together, and one click jumps both playheads to the
 * exact frame where their output stopped matching.
 *
 * @module dsh-replay-theater/client/CompareView
 */
import type { Divergence } from '../core/compare.ts';
import type { Timeline } from '../core/timeline.ts';
import type { Translate } from './dsh.ts';
import type { Playback } from './usePlayback.ts';
/** One side of a comparison. */
export interface CompareSide {
    readonly label: string;
    readonly timeline: Timeline;
    /** Live playback when this side is driven by a player; absent for static sides. */
    readonly playback?: Playback;
    /** Frame index to show when there is no playback. */
    readonly frameIndex?: number;
}
/** Comparison props. */
export interface CompareViewProps {
    readonly left: CompareSide;
    readonly right: CompareSide;
    readonly t: Translate;
}
/**
 * One-line explanation of a divergence.
 * @param divergence - the computed divergence.
 * @param t - translator.
 * @returns the human-readable line.
 */
export declare function describeDivergence(divergence: Divergence, t: Translate): string;
/**
 * Render two timelines side by side.
 * @param props - both sides and a translator.
 * @returns the comparison element.
 */
export declare function CompareView({ left, right, t }: CompareViewProps): JSX.Element;
//# sourceMappingURL=CompareView.d.ts.map