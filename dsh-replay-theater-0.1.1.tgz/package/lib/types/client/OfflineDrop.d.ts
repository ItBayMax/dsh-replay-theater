/**
 * Drop zone for a recorded `session.jsonl`.
 *
 * Offline replay exists for two reasons: comparing a live session against a
 * recorded baseline, and replaying a session this browser never had (a
 * teammate's log, a CI artifact, an upstream snapshot fixture).
 *
 * @module dsh-replay-theater/client/OfflineDrop
 */
import type { HistoryRecord } from '../core/wire.ts';
import type { Translate } from './dsh.ts';
/** What a successful load yields. */
export interface OfflineLog {
    readonly name: string;
    readonly records: readonly HistoryRecord[];
    /** True when the log carried no timestamps and the cadence is synthetic. */
    readonly synthesizedTimes: boolean;
    readonly skipped: number;
}
/** Drop-zone props. */
export interface OfflineDropProps {
    readonly t: Translate;
    readonly onLoad: (log: OfflineLog) => void;
}
/**
 * Render the file drop zone.
 * @param props - translator and load callback.
 * @returns the drop-zone element.
 */
export declare function OfflineDrop({ t, onLoad }: OfflineDropProps): JSX.Element;
//# sourceMappingURL=OfflineDrop.d.ts.map