/**
 * The stage: streamed output as it stood at the playhead.
 *
 * @module dsh-replay-theater/client/TheaterStage
 */
import type { StageState } from '../core/timeline.ts';
import type { Translate } from './dsh.ts';
/** Stage props. */
export interface TheaterStageProps {
    readonly stage: StageState;
    readonly t: Translate;
    /** True when the timeline itself is empty (nothing replayable in the window). */
    readonly emptyTimeline: boolean;
}
/**
 * Render the accumulated blocks.
 * @param props - stage state and translator.
 * @returns the stage element.
 */
export declare function TheaterStage({ stage, t, emptyTimeline }: TheaterStageProps): JSX.Element;
//# sourceMappingURL=TheaterStage.d.ts.map