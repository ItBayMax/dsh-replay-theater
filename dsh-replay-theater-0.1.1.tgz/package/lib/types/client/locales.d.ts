/**
 * Locale dictionaries for the theater.
 *
 * dsh 0.1.2 made locale ownership a hard rule: all product-authored client UI
 * wording belongs to locale dictionaries, Cordis-free atoms must receive
 * complete localized copy props with no fallback wording, and localized text
 * never carries identity (match first, translate second). So the dictionaries
 * exist from the first commit rather than being extracted later.
 *
 * @module dsh-replay-theater/client/locales
 */
/** Locale namespace this plugin owns. */
export declare const NS = "replay.theater";
/** English dictionary. Keys are stable identifiers; values are display copy. */
export declare const en: {
    readonly 'view.theater': "Theater";
    readonly 'control.play': "Play";
    readonly 'control.pause': "Pause";
    readonly 'control.stepBack': "Step back";
    readonly 'control.stepForward': "Step forward";
    readonly 'control.restart': "Restart";
    readonly 'control.speed': "Speed";
    readonly 'control.loadOlder': "Load earlier history";
    readonly 'control.loading': "Loading…";
    readonly 'stage.empty': "No replayable history in this window yet.";
    readonly 'stage.emptyHint': "Assistant output is replayed token by token once this session has streamed a reply.";
    readonly 'stage.reasoning': "Reasoning";
    readonly 'stage.toolCall': "Tool call";
    readonly 'stage.marker': "Event";
    readonly 'status.position': "Position";
    readonly 'status.total': "Total";
    readonly 'status.frames': "{count} frames";
    readonly 'status.compressed': "Long pauses compressed to {ms} ms";
    readonly 'settings.maxGap': "Max pause";
    readonly 'settings.maxGapHint': "Silences longer than this are compressed during playback.";
    readonly 'compare.title': "Side-by-side";
    readonly 'compare.left': "Left";
    readonly 'compare.right': "Right";
    readonly 'compare.pickRight': "Pick a session to compare";
    readonly 'compare.exit': "Exit comparison";
    readonly 'compare.divergeAt': "First divergence at seq {seq}";
    readonly 'compare.identical': "No divergence found in the loaded windows";
    readonly 'offline.title': "Open a recorded session";
    readonly 'offline.hint': "Drop a session.jsonl file here, or click to choose one.";
    readonly 'offline.parseError': "That file could not be read as a session log.";
    readonly 'offline.loaded': "Loaded {count} events from {name}";
    readonly 'offline.clear': "Close file";
    readonly 'offline.synthetic': "This log carried no timestamps — cadence is uniform, not original";
};
/** Chinese dictionary. Same key set as {@link en} — parity is a hard rule. */
export declare const zh: {
    readonly 'view.theater': "剧场";
    readonly 'control.play': "播放";
    readonly 'control.pause': "暂停";
    readonly 'control.stepBack': "上一帧";
    readonly 'control.stepForward': "下一帧";
    readonly 'control.restart': "重新播放";
    readonly 'control.speed': "倍速";
    readonly 'control.loadOlder': "加载更早的历史";
    readonly 'control.loading': "加载中…";
    readonly 'stage.empty': "当前窗口还没有可回放的历史。";
    readonly 'stage.emptyHint': "会话产生流式回复后，助手输出会逐 token 重演。";
    readonly 'stage.reasoning': "推理";
    readonly 'stage.toolCall': "工具调用";
    readonly 'stage.marker': "事件";
    readonly 'status.position': "进度";
    readonly 'status.total': "总时长";
    readonly 'status.frames': "{count} 帧";
    readonly 'status.compressed': "长静默已压缩到 {ms} 毫秒";
    readonly 'settings.maxGap': "最长停顿";
    readonly 'settings.maxGapHint': "超过该时长的静默会在回放时被压缩。";
    readonly 'compare.title': "并排对比";
    readonly 'compare.left': "左";
    readonly 'compare.right': "右";
    readonly 'compare.pickRight': "选择要对比的会话";
    readonly 'compare.exit': "退出对比";
    readonly 'compare.divergeAt': "首个分歧在 seq {seq}";
    readonly 'compare.identical': "已加载的窗口内没有发现分歧";
    readonly 'offline.title': "打开录制的会话";
    readonly 'offline.hint': "把 session.jsonl 拖到这里，或点击选择文件。";
    readonly 'offline.parseError': "这个文件无法作为会话日志读取。";
    readonly 'offline.loaded': "已从 {name} 载入 {count} 个事件";
    readonly 'offline.clear': "关闭文件";
    readonly 'offline.synthetic': "该日志没有时间戳——节奏是均匀的，不是原始节奏";
};
/** Key union for this namespace, used by the dsh locale service declaration. */
export type TheaterKey = keyof typeof en;
/**
 * Fill `{placeholder}` slots in a dictionary value.
 * @param template - the dictionary string.
 * @param values - replacement values by placeholder name.
 * @returns the formatted string; an unmatched placeholder is left verbatim.
 */
export declare function format(template: string, values: Readonly<Record<string, string | number>>): string;
//# sourceMappingURL=locales.d.ts.map