/**
 * Browser half of the replay theater: one `conversation.view` tab.
 *
 * The registration deliberately does NOT touch `ctx.uiConversation`'s
 * Conversation-target machinery. Upstream's `ui-trajectory` takes a target in
 * its `inject` (index.ts:77-106), but the theater only needs the session
 * itself — `session.eventSource` already carries the aligned history records,
 * so the whole Definition/snapshot-builder layer is unnecessary here. That is
 * the difference between an 11-file plugin and a 27-file one.
 *
 * @module dsh-replay-theater/client
 */
import type { TheaterClientContext } from './dsh.ts';
/** Services this plugin needs before it can register anything. */
export declare const inject: string[];
/** Loader-visible plugin name for the client module graph. */
export declare const name = "dsh-replay-theater/client";
/**
 * Register the dictionaries and the theater view tab.
 *
 * The tab label goes through the locale service like every other piece of
 * product copy (dsh 0.1.2 makes locale ownership a hard rule), which is why
 * the registration reads it from `ctx.locale.translate` rather than from the
 * English dictionary directly.
 * @param ctx - the client context.
 */
export declare function apply(ctx: TheaterClientContext): void;
//# sourceMappingURL=index.d.ts.map