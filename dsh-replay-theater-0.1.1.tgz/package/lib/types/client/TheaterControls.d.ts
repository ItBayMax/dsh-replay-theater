/**
 * The transport bar: play/pause, stepping, speed, scrub, and honest reporting
 * of how much silence playback compressed.
 *
 * @module dsh-replay-theater/client/TheaterControls
 */
import type { Playback } from './usePlayback.ts';
import type { Translate } from './dsh.ts';
/** Controls props. */
export interface TheaterControlsProps {
    readonly playback: Playback;
    readonly t: Translate;
    /** Current long-pause ceiling in ms; `Infinity` means true wall-clock cadence. */
    readonly gapCeiling: number;
    /** Change the ceiling, which rebuilds the timeline. */
    readonly onGapCeilingChange: (ms: number) => void;
    /** Page one older window in; absent when the caller cannot page. */
    readonly onLoadOlder?: () => void;
    readonly loadingOlder?: boolean;
    readonly canLoadOlder?: boolean;
}
/**
 * Format a millisecond position as `m:ss.d`.
 * @param ms - milliseconds.
 * @returns a compact human-readable position.
 */
export declare function formatPosition(ms: number): string;
/**
 * Render the transport bar.
 * @param props - playback handle, translator and paging hooks.
 * @returns the controls element.
 */
export declare function TheaterControls({ playback, t, gapCeiling, onGapCeilingChange, onLoadOlder, loadingOlder, canLoadOlder, }: TheaterControlsProps): JSX.Element;
//# sourceMappingURL=TheaterControls.d.ts.map