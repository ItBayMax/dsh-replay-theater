/**
 * React binding for the framework-free player.
 *
 * The hook owns exactly three things the core cannot: subscribing to the live
 * session window, driving `tick` from `requestAnimationFrame`, and exposing
 * imperative controls. Every playback rule stays in `core/player.ts`.
 *
 * @module dsh-replay-theater/client/usePlayback
 */
import type { Player, Speed } from '../core/player.ts';
import type { StageState, Timeline, TimelineOptions } from '../core/timeline.ts';
import type { ClientSession } from './dsh.ts';
/** What the view needs to render and control playback. */
export interface Playback {
    readonly timeline: Timeline;
    readonly player: Player;
    readonly stage: StageState;
    play: () => void;
    pause: () => void;
    toggle: () => void;
    stepBy: (delta: number) => void;
    seekTo: (positionMs: number) => void;
    setSpeed: (speed: Speed) => void;
    restart: () => void;
}
/**
 * Bind a session's history window to a playable, controllable timeline.
 * @param session - the client session whose window is replayed.
 * @param options - cadence tunables forwarded to the timeline builder.
 * @returns playback state and controls.
 */
export declare function usePlayback(session: ClientSession, options?: TimelineOptions): Playback;
//# sourceMappingURL=usePlayback.d.ts.map