/**
 * The theater tab: stage plus transport bar over one session's history window,
 * with an optional side-by-side comparison against a recorded log.
 *
 * @module dsh-replay-theater/client/TheaterView
 */
import type { TheaterInjected, Translate } from './dsh.ts';
/** Selectable long-pause ceilings, in milliseconds. `Infinity` keeps real cadence. */
export declare const GAP_CHOICES: readonly [200, 500, 2000, 5000, number];
/** Props the slot runtime composes for this view. */
export type TheaterViewProps = TheaterInjected & {
    /** Translator for this plugin's namespace, supplied by the slot runtime. */
    readonly t: Translate;
    /** Initial long-pause ceiling; the user can change it from the transport bar. */
    readonly maxGapMs?: number;
};
/**
 * Render the theater.
 * @param props - injected session face, translator and initial cadence tunable.
 * @returns the theater element.
 */
export declare function TheaterView({ session, loadOlder, t, maxGapMs }: TheaterViewProps): JSX.Element;
//# sourceMappingURL=TheaterView.d.ts.map